﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace SQL_Converter
{
    public partial class SQLConverter : Form
    {
        [DllImport("sqlparser.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.LPStr)]
        public static extern string OracleToSql([MarshalAs(UnmanagedType.LPStr)]string input, int input_size);//, out string output, out int out_size, out int lines);


        public SQLConverter()
        {
            InitializeComponent();
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new About().ShowDialog();
        }

        private void SQLConverter_Resize(object sender, EventArgs e)
        {
            int width = this.Width;
            int space = 60;


            txtSource.Width = (width - space) / 2;
            txtTarget.Width = (width - space) / 2;
            txtTarget.Left = txtSource.Left + txtSource.Width + 10;

            txtBoxError.Top = txtSource.Top + txtSource.Height + 20;
            lblErrorandWarning.Top = txtSource.Top + txtSource.Height + 5;

        }

        private void GrpHeader_Enter(object sender, EventArgs e)
        {

        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            string source = ddlSoruceType.SelectedItem.ToString();
            string target = ddlTargetType.SelectedItem.ToString();

            object z = OracleToSql(txtSource.Text, txtSource.Text.Length);//, out output, out out_size, out lines);
            //MessageBox.Show(Convert.ToString(z), "Answer", MessageBoxButtons.OK, MessageBoxIcon.Information);
            string sContent = Convert.ToString(z);
            int nPos = sContent.IndexOf("Error:");
            string sMessage = "";
            string sError = "";
            if (nPos > 0)
            {
                sMessage = sContent.Substring(0, nPos);
                sError = sContent.Substring(nPos + 8);
            }
            else
            {
                sMessage = sContent;
            }
            txtTarget.Text = sMessage;
            txtBoxError.Text = sError;
        }

        private void SQLConverter_Load(object sender, EventArgs e)
        {
            ddlSoruceType.SelectedIndex = 0;
            ddlTargetType.SelectedIndex = 0;

            /*
            Number (1)      -> BIT
            Number(2-3)     -> TINYINT
            Number(4-5)     -> SMALLINT
            NUMBER(6-9)    -> INT
            Number(10-19)   -> BIGINT
            Number(20)      -> DECIMAL
            NUMBER(5,1)     -> DECIMAL

             */
            
            string str = @"CREATE TABLE Test.STATION 
                            (ID RAW PRIMARY KEY,
                            CITY CHAR(20) NULL,
                            IsMale Number(1) NOT NULL, 
                            age1 Number(1,0),
                            age2 Number(2),
                            age3 Number(3),
                            age4 Number(4),
                            age5 Number(5),
                            age6 Number(6),
                            age8 Number(8), 
                            age9 Number(9),
                            age10 Number(10),
                            age11 Number(11),
                            age18 Number(18),
                            age19 Number(19),
                            age20 Number(20),
                            age21 Number(5,1)
                        ); ";
            txtSource.Text = str;
        }

    }
}
