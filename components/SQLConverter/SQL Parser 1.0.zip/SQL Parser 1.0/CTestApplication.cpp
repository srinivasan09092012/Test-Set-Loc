// CTestApplication.cpp : Defines the exported functions for the DLL application.
//

#include "sqlparser.h"
#include "wtypes.h"
#include "OleAuto.h"
#include "comdef.h"
#include <vector>
#include <string>

static bstr_t hello(L"Hello ");

/*extern "C" {
	__declspec(dllexport) int add(int a, int b) {
		return a + b;
	}
	__declspec(dllexport) int subtract(int a, int b) {
		return a - b;
	}
}*/

extern "C" {
	__declspec(dllexport) int __stdcall add(int a, int b) {
		return a + b;
	}

	//static bstr_t hi(L"Hello ");
	__declspec(dllexport) char * __stdcall helloWorld(const char* name) {

		int length = strlen(hello) + strlen(name) + 1;
		char *lpv = (char *)CoTaskMemAlloc(length);
		strcpy_s(lpv, length, hello);
		strcat_s(lpv, length, name);

		return lpv;
	}

	__declspec(dllexport) char * __stdcall outparameter(const char* name, char** output) {

		int length = strlen(hello) + strlen(name) + 1;
		char *lpv = (char *)CoTaskMemAlloc(length);
		strcpy_s(lpv, length, hello);
		strcat_s(lpv, length, name);

		*output = lpv;
		return S_OK;
	}

	
	__declspec(dllexport) char * __stdcall OracleToSql(const char* input, int size) {

		const char *output = NULL;
		int out_size = 0;
		int lines;

		const char *error = NULL;
		int err_size = 0;

		// Convert the file
		//rc = ConvertSql(_parser, input, size, &output, &out_size, &lines);

		/*const char **output = ;
		int *out_size = 0;
		int *lines = 0;*/
		SqlParser *parser = new SqlParser();
		parser->SetTypes(2, 1);
		parser->Convert(input, size, &output, &out_size, &lines, &error, &err_size);

		if (out_size == NULL && ( err_size == NULL || err_size == 0)) 
		{
			char *lpv = NULL;
			return lpv;
		}
		else
		{
			int length = 0;
			if (out_size != NULL)
			{
				length += out_size;
			}
			if (err_size != NULL || err_size != 0)
			{
				//Space for Error:\r\n
				length += 8;

				length += err_size;
			}
			length += 1; //Add One Additional Space

			char *lpv = (char *)CoTaskMemAlloc(length);
			//strcpy_s(lpv, length, output);
			strcpy(lpv, output);
			if (err_size != NULL || err_size != 0)
			{

				strcpy(lpv + out_size, "Error:\r\n");
				strcpy(lpv + out_size + 8, error);
			}
			return lpv;
		}
	}
}